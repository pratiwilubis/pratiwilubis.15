
// Advanced rule-based grammar checker (rule sets simplified for client-side use)

const irregularVerbs = {
  "be": ["am","is","are","was","were","been","being"],
  "see": ["see","saw","seen","seeing"],
  "go": ["go","goes","went","gone","going"],
  "do": ["do","does","did","done","doing"],
  "have": ["have","has","had","having"],
  "make": ["make","makes","made","making"],
  "play": ["play","plays","played","playing"],
  "read": ["read","reads","read","reading"],
  "eat": ["eat","eats","ate","eaten","eating"],
  "write": ["write","writes","wrote","written","writing"],
  "take": ["take","takes","took","taken","taking"]
};

const subjectVerbRules = [
  {subjects:["he","she","it"], allowedVerbs:["is","has","does","goes","plays","reads"]},
  {subjects:["i"], allowedVerbs:["am","have","do","go","play","read"]},
  {subjects:["we","they","you"], allowedVerbs:["are","have","do","go","play","read"]}
];

const articles = ["a","an","the"];

const prepositions = [
  {prev:"good", next:"at"},
  {prev:"interested", next:"in"},
  {prev:"depend", next:"on"},
  {prev:"look", next:"at"}
];

const pluralMistakes = {
  "childs":"children",
  "mouses":"mice",
  "peoples":"people"
};

function checkGrammar(){
  const input = document.getElementById("sentenceInput").value.trim();
  const resultContainer = document.getElementById("resultContainer");
  resultContainer.innerHTML="";

  if(!input){
    resultContainer.innerHTML="<div class='error-card'>Please enter a sentence!</div>";
    return;
  }

  const words = input.split(/\s+/);
  const errors = [];

  words.forEach((w,i)=>{
    const lower = w.toLowerCase().replace(/[^a-z']/g,""); // strip punctuation
    if(!lower) return;

    // Subject-Verb Agreement (check the current word as verb following a subject)
    subjectVerbRules.forEach(rule=>{
      if(i>0 && rule.subjects.includes(words[i-1]?.toLowerCase())){
        if(!rule.allowedVerbs.includes(lower)){
          // allow past tense forms (simplified): if lower is in irregular forms permit
          let allowedPast = false;
          Object.keys(irregularVerbs).forEach(k=>{ if(irregularVerbs[k].includes(lower)) allowedPast=true; });
          if(!allowedPast){
            errors.push({word:w, rule:`Verb "${w}" may not match subject "${words[i-1]}".`});
          }
        }
      }
    });

    // Articles: a/an mismatch
    if(articles.includes(lower)){
      const next = (words[i+1] || "").toLowerCase().replace(/[^a-z']/g,""); 
      if(lower==="a" && next && ["a","e","i","o","u"].includes(next[0])) {
        errors.push({word:w, rule:`Use "an" before vowel sound, not "a".`});
      }
      if(lower==="an" && next && !["a","e","i","o","u"].includes(next[0])) {
        errors.push({word:w, rule:`Use "a" before consonant sound, not "an".`});
      }
    }

    // Preposition common pairs
    prepositions.forEach(p=>{
      if(words[i-1]?.toLowerCase()===p.prev && lower!==p.next){
        errors.push({word:w, rule:`Preposition after "${p.prev}" should usually be "${p.next}".`});
      }
    });

    // Plural common mistakes
    if(pluralMistakes[lower]){
      errors.push({word:w, rule:`Plural mistake: use "${pluralMistakes[lower]}" instead of "${w}".`});
    }

    // Irregular verb sequence check: if previous word is base verb key, current should be a valid form
    Object.keys(irregularVerbs).forEach(k=>{
      if(words[i-1]?.toLowerCase()===k && !irregularVerbs[k].includes(lower)){
        errors.push({word:w, rule:`Verb form "${w}" may be incorrect after "${k}".`});
      }
    });
  });

  if(errors.length===0){
    resultContainer.innerHTML="<div class='correct-card center'>✅ No errors detected! Well done.</div>";
  } else {
    errors.forEach(e=>{
      resultContainer.innerHTML += `<div class='error-card'>❌ <strong>${e.word}</strong> - ${e.rule}</div>`;
    });
  }
}
