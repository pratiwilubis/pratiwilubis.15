
const quizData = [
  // Easy (20 sample)
  { q:"She ____ to school every day.", options:["go","goes","gone","going"], correct:1, level:"Easy" },
  { q:"I ____ like apples.", options:["don't","doesn't","isn't","aren't"], correct:0, level:"Easy" },
  { q:"He ____ happy today.", options:["is","are","am","be"], correct:0, level:"Easy" },
  { q:"We ____ friends.", options:["is","are","am","be"], correct:1, level:"Easy" },
  { q:"They ____ play football.", options:["don't","doesn't","isn't","aren't"], correct:0, level:"Easy" },
  { q:"She ____ cooking.", options:["like","likes","liked","liking"], correct:1, level:"Easy" },
  { q:"I ____ a book.", options:["reading","reads","am reading","is read"], correct:2, level:"Easy" },
  { q:"You ____ tired.", options:["is","are","am","be"], correct:1, level:"Easy" },
  { q:"He ____ not know the answer.", options:["do","does","did","doing"], correct:1, level:"Easy" },
  { q:"They ____ watching TV.", options:["is","are","am","be"], correct:1, level:"Easy" },
  { q:"I ____ going to school.", options:["am","is","are","be"], correct:0, level:"Easy" },
  { q:"She ____ likes chocolate.", options:["do","does","is","are"], correct:1, level:"Easy" },
  { q:"We ____ not hungry.", options:["is","are","am","be"], correct:1, level:"Easy" },
  { q:"He ____ reading a book.", options:["am","is","are","be"], correct:1, level:"Easy" },
  { q:"You ____ a good student.", options:["is","are","am","be"], correct:1, level:"Easy" },
  { q:"They ____ swimming every weekend.", options:["do","does","are","is"], correct:2, level:"Easy" },
  { q:"I ____ breakfast now.", options:["am eating","is eating","are eating","eat"], correct:0, level:"Easy" },
  { q:"She ____ not know the answer.", options:["does","do","is","are"], correct:0, level:"Easy" },
  { q:"We ____ very happy today.", options:["is","are","am","be"], correct:1, level:"Easy" },
  { q:"He ____ working hard.", options:["is","are","am","be"], correct:0, level:"Easy" },

  // Medium (15 sample)
  { q:"They ____ finished their homework before dinner.", options:["has","have","had","having"], correct:2, level:"Medium" },
  { q:"He was angry because he ____ the bus.", options:["miss","missed","misses","missing"], correct:1, level:"Medium" },
  { q:"I ____ never seen such a beautiful sunset.", options:["has","have","had","having"], correct:1, level:"Medium" },
  { q:"She ____ already eaten.", options:["has","have","had","having"], correct:0, level:"Medium" },
  { q:"By the time he arrived, we ____ left.", options:["has","have","had","having"], correct:2, level:"Medium" },
  { q:"If it ____ tomorrow, we will cancel the trip.", options:["rains","rain","rained","rainy"], correct:0, level:"Medium" },
  { q:"He asked me where I ____ last night.", options:["was","were","am","is"], correct:0, level:"Medium" },
  { q:"I wish I ____ more time.", options:["have","had","has","having"], correct:1, level:"Medium" },
  { q:"She suggested that he ____ earlier.", options:["arrives","arrived","arrive","arriving"], correct:2, level:"Medium" },
  { q:"He would have helped if he ____ knew.", options:["has","have","had","having"], correct:2, level:"Medium" },
  { q:"By next week, they ____ completed the project.", options:["will have","will has","would have","would has"], correct:0, level:"Medium" },
  { q:"I am used to ____ up early.", options:["wake","waking","woken","wakes"], correct:1, level:"Medium" },
  { q:"She is capable of ____ the task alone.", options:["complete","completing","completed","completes"], correct:1, level:"Medium" },
  { q:"He denied ____ the vase.", options:["break","breaking","broke","breaks"], correct:1, level:"Medium" },
  { q:"I look forward to ____ from you.", options:["hearing","hear","heard","hears"], correct:0, level:"Medium" },

  // Hard (10 sample)
  { q:"If I ____ you, I would apologize immediately.", options:["am","were","was","be"], correct:1, level:"Hard" },
  { q:"The cake ____ by my mother yesterday.", options:["bake","was baked","is baked","has baked"], correct:1, level:"Hard" },
  { q:"Had I known, I ____ attended the meeting.", options:["would","will","shall","should"], correct:0, level:"Hard" },
  { q:"No sooner ____ he arrived than it started raining.", options:["did","do","does","was"], correct:0, level:"Hard" },
  { q:"Hardly ____ she left when the phone rang.", options:["had","has","have","did"], correct:0, level:"Hard" },
  { q:"It is high time we ____ to the doctor.", options:["go","went","goes","going"], correct:1, level:"Hard" },
  { q:"She acts as if she ____ the boss.", options:["is","are","was","were"], correct:3, level:"Hard" },
  { q:"I would rather you ____ here now.", options:["are","be","were","been"], correct:2, level:"Hard" },
  { q:"This is the first time I ____ such a thing.", options:["see","saw","seen","seeing"], correct:2, level:"Hard" },
  { q:"He speaks English as if he ____ in London.", options:["lives","live","lived","living"], correct:2, level:"Hard" }
];

let currentQuestionIndex = 0;
let filteredData = [];
let progressStep = 0;
let streak = 0;
let maxStreak = 0;

function startQuiz(level){
  filteredData = quizData.filter(q=>q.level===level);
  currentQuestionIndex = 0;
  progressStep = 100/filteredData.length;
  streak=0; maxStreak=0;
  filteredData.forEach(q=>q.userAnswer=null);
  document.getElementById("levelSelect").style.display = "none";
  document.getElementById("quizContainer").style.display = "block";
  document.getElementById("streakDisplay").innerHTML = "";
  document.getElementById("fireBackground").style.opacity = 0;
  showQuestion();
  updateProgress();
}

function showQuestion(){
  const quiz = filteredData[currentQuestionIndex];
  const box = document.getElementById("quizBox");
  document.getElementById("levelIndicator").innerText = "Level: "+quiz.level;
  box.innerHTML = `<div class='quiz-question'>${quiz.q}</div>`;
  quiz.options.forEach((opt,idx)=>{
    box.innerHTML += `<div class='quiz-option' onclick='checkAnswer(this,${idx},${quiz.correct})'>${opt}</div>`;
  });
}

function checkAnswer(el,chosen,correct){
  const quiz = filteredData[currentQuestionIndex];
  quiz.userAnswer = chosen;
  const streakDisplay = document.getElementById("streakDisplay");
  const fireBG = document.getElementById("fireBackground");

  if(chosen === correct){
    el.classList.add("correct"); el.innerHTML+=" ✔️";
    streak++; if(streak>maxStreak) maxStreak = streak;
  } else {
    el.classList.add("wrong"); el.innerHTML+=" ❌"; streak=0;
    const siblings = el.parentElement.querySelectorAll(".quiz-option");
    siblings[correct].classList.add("correct"); siblings[correct].innerHTML+=" 🎉";
  }

  streakDisplay.innerHTML = `🔥 Streak: ${streak} 🔥`;
  streakDisplay.className = "streak-display";
  if(streak>=5) streakDisplay.classList.add("streak5");
  else if(streak>=3) streakDisplay.classList.add("streak3");
  else if(streak>=1) streakDisplay.classList.add("streak1");

  fireBG.style.opacity = streak>=3 ? 0.6 : 0;

  const options = el.parentElement.querySelectorAll(".quiz-option");
  options.forEach(o=>o.onclick=null);
}

function nextQuestion(){
  if(currentQuestionIndex < filteredData.length-1){
    currentQuestionIndex++;
    showQuestion();
    updateProgress();
  } else {
    const correctCount = filteredData.filter(q=>q.userAnswer===q.correct).length;
    const wrongCount = filteredData.length - correctCount;
    const box = document.getElementById("quizBox");
    box.innerHTML = `
      <div class="section center">
        <h2>🎉 Quiz Completed! 🎉</h2>
        <p>Total Questions: ${filteredData.length}</p>
        <p>✅ Correct: ${correctCount}</p>
        <p>❌ Wrong: ${wrongCount}</p>
        ${correctCount === filteredData.length ? '<h3>🌟 Perfect Score! Amazing! 🌟</h3>' : ''}
        <button class="button" onclick="restartQuiz()">Restart Quiz 🔄</button>
        <a href="index.html" class="button">Back to Home 🏠</a>
      </div>
    `;
    streak=0; maxStreak=0;
    document.getElementById("streakDisplay").innerHTML="";
    document.getElementById("fireBackground").style.opacity=0;
    document.getElementById("progressBar").style.width = "100%";
  }
}

function updateProgress(){
  document.getElementById("progressBar").style.width = `${(currentQuestionIndex+1)*progressStep}%`;
}

function restartQuiz(){
  document.getElementById("levelSelect").style.display="block";
  document.getElementById("quizContainer").style.display="none";
}
